/**
 * @author yisheng.cl
 * @email [yisheng.cl@alibaba-inc.com]
*/
/** 从公钥证书文件里读取支付宝公钥 */
declare function loadPublicKeyFromPath(filePath: string): string;
/** 从公钥证书内容或buffer读取支付宝公钥 */
declare function loadPublicKey(content: string | Buffer): string;
/** 从证书文件里读取序列号 */
declare function getSNFromPath(filePath: string, isRoot?: boolean): string;
/** 从上传的证书内容或Buffer读取序列号 */
declare function getSN(fileData: string | Buffer, isRoot?: boolean): string;
export { getSN, getSNFromPath, loadPublicKeyFromPath, loadPublicKey, };
