function foo () {
  return a('bar') || b();
}
