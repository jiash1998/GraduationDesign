
1.0.0 / 2015-08-06
==================

 * use npm scripts
 * added os-name package

0.0.1 / 2014-03-13 
==================

  * first commit
